const soma = require('./modules/calculadora.js');

// import { subtrair, multiplicar } from './calculadora.js';

console.log(soma(10, 5));

// console.log(subtrair(30, 10));
// console.log(multiplicar(2, 3));