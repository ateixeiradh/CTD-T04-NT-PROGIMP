// // módulo "calculadora.js"

// // export { somar, subtrair, multiplicar };

// //Adição
// export function somar(numberA,numberB){
//     return numberA + numberB;
    
// }

// //Subtração
// export function subtrair(numberA,numberB){
//     return numberA - numberB;
    
// }

// //Multiplicação
// export function multiplicar(numberA,numberB) {
//     return numberA * numberB;
// }

// //Divisão
// export function dividir(numberA,numberB){
//     return numberA / numberB;
    
// }

// module.exports = {somar, subtrair, multiplicar}; 

module.exports = function soma(a, b) {
    return a + b;
}
