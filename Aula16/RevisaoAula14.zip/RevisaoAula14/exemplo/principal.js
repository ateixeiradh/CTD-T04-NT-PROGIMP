const superHerois = require('./superHeroes')

console.log(superHerois)
